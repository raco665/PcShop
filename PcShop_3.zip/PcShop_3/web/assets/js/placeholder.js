
jQuery(document).ready(function(){
	
	$('.subscribe-email').val('Enter your email...');
	
});